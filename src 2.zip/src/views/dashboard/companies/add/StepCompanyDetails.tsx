import React from 'react'

const StepCompanyDetails = () => {
  return (
    <div>
      {/* İstenirse ek detaylar buraya konulabilir.
          Kullanılmayacaksa bileşen boş kalabilir veya silinebilir. */}
    </div>
  )
}

export default StepCompanyDetails
